document.addEventListener('DOMContentLoaded', function () {
  // Function to handle search button click
  function handleSearch() {
    alert('Search button clicked!'); // Example action, replace with actual search functionality
  }

  // Add event listener to search button
  document.getElementById('searchButton').addEventListener('click', handleSearch);

  // Function to handle login button click
  function handleLogin() {
    alert('Login button clicked!'); // Example action, replace with actual login functionality
  }

  // Add event listener to login button
  document.getElementById('form-open').addEventListener('click', () => {
    document.querySelector(".home").classList.add("show");
  });

  document.querySelector(".form_close").addEventListener('click', () => {
    document.querySelector(".home").classList.remove("show");
})});

//


 